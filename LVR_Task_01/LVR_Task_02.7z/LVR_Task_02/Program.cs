﻿using System;

namespace LVR_Task_02
{
    class Program
    {
        static void Main(string[] args)
        {
            string word = null;
            while (word != "exit")
            {
                word = Console.ReadLine();
            }
        }
    }
}
